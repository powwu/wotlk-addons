local L = LibStub("AceLocale-3.0"):NewLocale("OneBag3", "itIT")

if L then
    --@non-debug@
--[[Translation missing --]]
--[[ L["%s's Bags"] = ""--]] 
--[[Translation missing --]]
--[[ L["Backpack"] = ""--]] 
--[[Translation missing --]]
--[[ L["First Bag"] = ""--]] 
--[[Translation missing --]]
--[[ L["Fourth Bag"] = ""--]] 
--[[Translation missing --]]
--[[ L["Second Bag"] = ""--]] 
--[[Translation missing --]]
--[[ L["Specific Bag Filters"] = ""--]] 
--[[Translation missing --]]
--[[ L["Third Bag"] = ""--]] 
--[[Translation missing --]]
--[[ L["Toggles the display of your Backpack."] = ""--]] 
--[[Translation missing --]]
--[[ L["Toggles the display of your First Bag."] = ""--]] 
--[[Translation missing --]]
--[[ L["Toggles the display of your Fourth Bag."] = ""--]] 
--[[Translation missing --]]
--[[ L["Toggles the display of your Second Bag."] = ""--]] 
--[[Translation missing --]]
--[[ L["Toggles the display of your Third Bag."] = ""--]] 

    --@end-non-debug@
end
