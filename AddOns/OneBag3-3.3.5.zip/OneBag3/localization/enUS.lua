local L = LibStub("AceLocale-3.0"):NewLocale("OneBag3", "enUS", true, true)

--@non-debug@
L["Backpack"] = true
L["First Bag"] = true
L["Fourth Bag"] = true
L["Second Bag"] = true
L["Specific Bag Filters"] = true
L["%s's Bags"] = true
L["Third Bag"] = true
L["Toggles the display of your Backpack."] = true
L["Toggles the display of your First Bag."] = true
L["Toggles the display of your Fourth Bag."] = true
L["Toggles the display of your Second Bag."] = true
L["Toggles the display of your Third Bag."] = true

--@end-non-debug@
