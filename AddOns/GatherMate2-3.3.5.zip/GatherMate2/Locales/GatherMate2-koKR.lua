﻿-- GatherMate Locale
-- Please use the Localization App on WoWAce to Update this
-- http://www.wowace.com/projects/gathermate2/localization/ ;¶

local L = LibStub("AceLocale-3.0"):NewLocale("GatherMate2", "koKR")
if not L then return end

--@localization(locale="koKR", format="lua_additive_table", namespace="Options", table-name="L", handle-unlocalized="comment")@

local NL = LibStub("AceLocale-3.0"):NewLocale("GatherMate2Nodes", "koKR")
if not NL then return end

--@localization(locale="koKR", format="lua_additive_table", namespace="Nodes", table-name="NL", handle-unlocalized="comment")@
